// // -------------------------------------- ASSIGNMENT NO 2 ---------------------------------------- //

// // Q# 1 :- Declare a variable called username.

var userName;

// // Q# 2 :- Declare a variable called myName & assign to it a string that represents your Full Name.

var myName = "Muhammad Ashir Ansari";

// /* Q# 3 :- Write script to

// a) Declare a JS variable, titled message.
// b) Assign “Hello World” to variable message
// c) Display the message in alert box. */

let message;
message = "This is my first website";
alert(message);

//  /* Q# 4 :- Write a script to save student’s bio data in JS variables and show the data in alert boxes. */

var studentName = "Muhammad Ashir Ansari";
var Age = "25";
var Postion = "Blockchain Developer";

console.log(alert(studentName + "\n", alert(Age + "\n", alert(Postion))));

// //  Q# 5 :- Write a script to display the following alert using one JS variable:

var JSVariable = "Muhammad Ashir Ansari";
alert(
  JSVariable +
    "\n" +
    "ASHIR" +
    "\n" +
    "ASHI" +
    "\n" +
    "ASH" +
    "\n" +
    "AS" +
    "\n" +
    "A"
);

// /*  Q# 6 :- Declare a variable called email and assign to it a string that represents your
//             Email Address(e.g. example@example.com). Show the blow mentioned message in an
//             alert box.(Hint: use string concatenation) */

let email;
email = "My Email Address Is :- " + "example@gmail.com";
alert(email);
console.log(email);

// /*  Q# 7 :- Declare a variable called book & give it the value “A smarter way to learn JavaScript”. Display the following
//             message in an alert box: */

let book = " A smarter way to learn JavaScript";
message = "I am trying to learn from the Book";
alert(message + book);

// ----------------------------------- Q #8 HTML file mae hai -------------------------------------- //

/*  Q# 9 :- Store following string in a variable and show in alert and browser through JS
“ ▬▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬ ” */

var JsVar = "▬▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬";
alert(JsVar);
console.log(JsVar);
